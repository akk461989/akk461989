#!/bin/bash
echo "Moving Fonts into Font Folder"
echo "Need root access. Type your (sudo) Login Password."
sudo mkdir /usr/share/fonts/truetype/pds
sudo mv *.ttf /usr/share/fonts/truetype/pds/
echo "Done."
echo "Have a nice time"
cd .. && rm -rf PyiDaungSuForKali